import React, { useState } from "react";
import {
  BarChart3,
  MapIcon,
  Users,
  ClipboardList,
  CheckSquare,
  BookOpen,
} from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
  SheetDescription,
} from "./ui/sheet";
import { Button } from "./ui/button";
import { Menu, User, RefreshCw, Settings, Globe } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import bayerLogo from "figma:asset/faad7d106e3b718dd388ae52af3802c375d98da5.png";

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
  region: string;
  season: string;
  onRegionChange: (region: string) => void;
  onSeasonChange: (season: string) => void;
}

const NAV_ITEMS = [
  { label: "Analytics", icon: BarChart3, id: "analytics" },
  { label: "Growers", icon: Users, id: "growers" },
  { label: "Plots", icon: MapIcon, id: "plots" },
  { label: "Advisory Tasks", icon: ClipboardList, id: "advisory" },
];

export function Layout({
  children,
  activeTab,
  onTabChange,
  region,
  season,
  onRegionChange,
  onSeasonChange,
}: LayoutProps) {
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  // Show all nav items in bottom navigation
  const bottomNavItems = NAV_ITEMS;

  return (
    <div className="relative flex flex-col h-full w-full bg-gray-50 overflow-hidden">
      {/* Mobile Top Header */}
      <div className="py-3 bg-[#4CAF50] text-white shadow-md z-20 px-4">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <img
              src={bayerLogo}
              alt="Logo"
              className="h-8 w-8 object-contain"
            />
            <h1 className="font-semibold text-base">Field Assistant</h1>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 bg-white px-2 py-1 rounded-full">
              <div className="h-2 w-2 rounded-full bg-[#4CAF50] animate-pulse" />
              <span className="text-[10px] text-[#4CAF50] font-medium">
                Connected
              </span>
            </div>
            <Sheet open={isProfileOpen} onOpenChange={setIsProfileOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="text-white hover:bg-white/10 rounded-full h-9 w-9"
                >
                  <User className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-full sm:w-80 p-0">
                <div className="flex flex-col h-full">
                  {/* Header */}
                  <div className="px-6 py-5 border-b bg-white">
                    <SheetTitle className="text-lg font-semibold text-slate-900">
                      Profile & Settings
                    </SheetTitle>
                    <SheetDescription className="text-sm text-slate-500 mt-1">
                      Manage your profile and preferences
                    </SheetDescription>
                  </div>

                  {/* Content */}
                  <div className="flex-1 overflow-y-auto px-6 py-6 pb-20 space-y-6">
                    {/* User Profile Card */}
                    <div className="bg-gradient-to-br from-[#4CAF50] to-[#45a049] rounded-xl p-5 shadow-md">
                      <div className="flex items-center gap-4">
                        <div className="h-20 w-20 rounded-full bg-white flex items-center justify-center text-[#4CAF50] font-bold text-2xl shadow-lg ring-4 ring-white/30">
                          JF
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-bold text-white">
                            John Field
                          </h3>
                          <p className="text-sm text-white/90 mt-0.5">
                            Field Assistant
                          </p>
                          <p className="text-xs text-white/75 mt-1">
                            ID: FA-2024-001
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Last Synced Section */}
                    <div>
                      <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                        Sync Status
                      </h4>
                      <button className="flex items-center justify-between w-full p-4 rounded-lg bg-slate-50 hover:bg-slate-100 transition-colors border border-slate-200">
                        <div className="text-left">
                          <p className="text-sm font-semibold text-slate-800">
                            Last Synced
                          </p>
                          <p className="text-xs text-slate-500 mt-0.5">
                            Today, 10:30 AM
                          </p>
                        </div>
                        <RefreshCw className="h-5 w-5 text-[#4CAF50] flex-shrink-0" />
                      </button>
                    </div>

                    {/* Preferences Section */}
                    <div>
                      <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                        Preferences
                      </h4>
                      <div className="space-y-2">
                        <Button
                          variant="outline"
                          className="w-full justify-between h-12 text-sm font-medium hover:bg-slate-50 border-slate-200"
                        >
                          <div className="flex items-center gap-3">
                            <Globe className="h-5 w-5 text-slate-600" />
                            <span className="text-slate-800">
                              Change Language
                            </span>
                          </div>
                          <span className="text-sm font-semibold text-slate-500">
                            EN
                          </span>
                        </Button>
                        <Button
                          variant="outline"
                          className="w-full justify-between h-12 text-sm font-medium hover:bg-slate-50 border-slate-200"
                        >
                          <div className="flex items-center gap-3">
                            <Settings className="h-5 w-5 text-slate-600" />
                            <span className="text-slate-800">Settings</span>
                          </div>
                        </Button>
                      </div>
                    </div>

                    {/* Account Section */}
                    <div>
                      <h4 className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-3">
                        Account
                      </h4>
                      <Button
                        variant="outline"
                        className="w-full justify-start h-12 text-sm font-medium text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200 hover:border-red-300"
                      >
                        <svg
                          className="h-5 w-5 mr-3"
                          fill="none"
                          viewBox="0 0 24 24"
                          stroke="currentColor"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                          />
                        </svg>
                        <span className="font-semibold">Logout</span>
                      </Button>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <Select value={region} onValueChange={onRegionChange}>
            <SelectTrigger className="h-7 text-xs bg-white/10 border-0 text-white hover:bg-white/20 rounded-md focus:ring-0 focus:ring-offset-0 [&_svg]:!text-white">
              <SelectValue placeholder="State" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All States</SelectItem>
              <SelectItem value="punjab">Punjab</SelectItem>
              <SelectItem value="haryana">Haryana</SelectItem>
              <SelectItem value="uttar-pradesh">Uttar Pradesh</SelectItem>
              <SelectItem value="maharashtra">Maharashtra</SelectItem>
              <SelectItem value="gujarat">Gujarat</SelectItem>
              <SelectItem value="rajasthan">Rajasthan</SelectItem>
            </SelectContent>
          </Select>

          <Select value={season} onValueChange={onSeasonChange}>
            <SelectTrigger className="h-7 text-xs bg-white/10 border-0 text-white hover:bg-white/20 rounded-md focus:ring-0 focus:ring-offset-0 [&_svg]:!text-white">
              <SelectValue placeholder="Season" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current">Kharif 2025</SelectItem>
              <SelectItem value="previous">Rabi 2024</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Page Content */}
      <main className="flex-1 overflow-y-auto pb-17 px-3 pt-3 bg-[#f5f5f5] [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
        {children}
      </main>

      {/* Bottom Navigation - 4 tabs in 1 row */}
      <div className="absolute bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-20">
        <div className="grid grid-cols-4 gap-0">
          {bottomNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`flex flex-col items-center justify-center gap-0.5 py-2 px-1 transition-all duration-200 border-b-2 ${
                  isActive
                    ? "text-[#4CAF50] border-[#4CAF50] bg-green-50"
                    : "text-gray-400 border-transparent"
                }`}
              >
                <Icon className={`h-5 w-5 ${isActive ? "scale-110" : ""}`} />
                <span className="text-[9px] font-medium whitespace-nowrap mt-0.5">
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
