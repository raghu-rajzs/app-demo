import React from "react";
import {
  Users,
  Grid,
  Ruler,
  Sprout,
  Leaf,
  Flower,
  Combine,
  Truck,
  Plus,
  TriangleAlert,
  Clock,
} from "lucide-react";

interface AnalyticsProps {
  onNavigateToPlots?: (
    auditFilter?: "all" | "audited" | "pending",
    stageFilter?: string,
  ) => void;
  onNavigateToAdvisory?: (status: string) => void;
  onNavigateToGrowers?: () => void;
}

interface KPICard {
  id: string;
  value: number | string;
  unit?: string;
  label: string;
  icon: React.ReactNode;
  backgroundColor: string;
  borderColor: string;
  shadowColor: string;
  iconBgColor: string;
  iconColor: string;
  textColor: string;
  unitColor?: string;
  subtitle?: string;
  subtitleColor?: string;
  onCard?: boolean;
  borderAccent?: string;
  onClick?: () => void;
}

export function Analytics({
  onNavigateToPlots,
  onNavigateToAdvisory,
  onNavigateToGrowers,
}: AnalyticsProps) {
  // Mock Data for KPIs
  const highlightCards: KPICard[] = [
    {
      id: "growers",
      value: 33,
      label: "No. of Growers",
      icon: <Users className="w-5 h-5" />,
      backgroundColor: "#FFF8DC",
      borderColor: "#EAC117",
      shadowColor: "#DA A520",
      iconBgColor: "#FCEABB",
      iconColor: "#B8860B",
      textColor: "#5C4300",
      onClick: () => onNavigateToGrowers?.(),
    },
    {
      id: "fields",
      value: 124,
      label: "No. of Fields",
      icon: <Grid className="w-5 h-5" />,
      backgroundColor: "#FFF8DC",
      borderColor: "#EAC117",
      shadowColor: "#DAA520",
      iconBgColor: "#FCEABB",
      iconColor: "#B8860B",
      textColor: "#5C4300",
      onClick: () => onNavigateToPlots?.("all"),
    },
    {
      id: "measured-acre",
      value: "847.5",
      label: "Measured Acre",
      icon: <Ruler className="w-5 h-5" />,
      backgroundColor: "#FFF8DC",
      borderColor: "#EAC117",
      shadowColor: "#DAA520",
      iconBgColor: "#FCEABB",
      iconColor: "#B8860B",
      textColor: "#5C4300",
      onClick: () => onNavigateToPlots?.("audited"),
    },
  ];

  const cropStageCards: KPICard[] = [
    {
      id: "sown-acreage",
      value: 145,
      unit: "Acre",
      label: "Sown Acreage",
      icon: <Sprout className="w-5 h-5" />,
      backgroundColor: "#fff",
      borderColor: "#e5e7eb",
      shadowColor: "rgba(0,0,0,0.08)",
      iconBgColor: "#e8f5e9",
      iconColor: "#2e7d32",
      textColor: "#1a1a1a",
      unitColor: "#888",
      onClick: () => {},
    },
    {
      id: "vegetative",
      value: 89,
      unit: "T",
      label: "Vegetative / Transplanting",
      icon: <Leaf className="w-5 h-5" />,
      backgroundColor: "#fff",
      borderColor: "#e5e7eb",
      shadowColor: "rgba(0,0,0,0.08)",
      iconBgColor: "#e8f5e9",
      iconColor: "#2e7d32",
      textColor: "#1a1a1a",
      unitColor: "#888",
      subtitle: "Standing 67.5 Acre",
      subtitleColor: "#558b2f",
      onClick: () => onNavigateToPlots?.("all", "Vegetative"),
    },
    {
      id: "flowering",
      value: 120,
      unit: "T",
      label: "Flowering Stage",
      icon: <Flower className="w-5 h-5" />,
      backgroundColor: "#fff",
      borderColor: "#e5e7eb",
      shadowColor: "rgba(0,0,0,0.08)",
      iconBgColor: "#f1f8e9",
      iconColor: "#558b2f",
      textColor: "#1a1a1a",
      unitColor: "#888",
      subtitle: "Standing 98.2 Acre",
      subtitleColor: "#558b2f",
      onClick: () => onNavigateToPlots?.("all", "Flowering"),
    },
    {
      id: "harvest",
      value: 156,
      unit: "T",
      label: "Harvest Stage",
      icon: <Combine className="w-5 h-5" />,
      backgroundColor: "#fff",
      borderColor: "#e5e7eb",
      shadowColor: "rgba(0,0,0,0.08)",
      iconBgColor: "#e8f5e9",
      iconColor: "#33691e",
      textColor: "#1a1a1a",
      unitColor: "#888",
      subtitle: "Harvested 112.3 Acre",
      subtitleColor: "#558b2f",
      onClick: () => onNavigateToPlots?.("all", "Harvest"),
    },
    {
      id: "dispatch",
      value: 34200,
      unit: "Kg",
      label: "Dispatch Stage",
      icon: <Truck className="w-5 h-5" />,
      backgroundColor: "#fff",
      borderColor: "#e5e7eb",
      shadowColor: "rgba(0,0,0,0.08)",
      iconBgColor: "#e0f2f1",
      iconColor: "#00695c",
      textColor: "#1a1a1a",
      unitColor: "#888",
      subtitle: "Dispatch 45.8 Acre",
      subtitleColor: "#558b2f",
      onClick: () => {},
    },
  ];

  const alertCards: KPICard[] = [
    {
      id: "pre-sowing-plots",
      value: 12,
      unit: "Plots",
      label: "Plots Pending Pre-Sowing",
      icon: <Plus className="w-5 h-5" />,
      backgroundColor: "#fff",
      borderColor: "#e5e7eb",
      shadowColor: "rgba(0,0,0,0.08)",
      iconBgColor: "#fff3e0",
      iconColor: "#e65100",
      textColor: "#1a1a1a",
      unitColor: "#888",
      onClick: () => onNavigateToPlots?.("pending"),
    },
    {
      id: "pending-tasks",
      value: 28,
      unit: "Tasks",
      label: "Pending Tasks",
      icon: <TriangleAlert className="w-5 h-5" />,
      backgroundColor: "#fff",
      borderColor: "#e5e7eb",
      shadowColor: "rgba(0,0,0,0.08)",
      iconBgColor: "#fff3e0",
      iconColor: "#e65100",
      textColor: "#1a1a1a",
      unitColor: "#888",
      borderAccent: "#ff9800",
      onClick: () => onNavigateToAdvisory?.("Pending"),
    },
    {
      id: "overdue-tasks",
      value: 3,
      unit: "Tasks",
      label: "Overdue Tasks",
      icon: <Clock className="w-5 h-5" />,
      backgroundColor: "#fff",
      borderColor: "#e5e7eb",
      shadowColor: "rgba(0,0,0,0.08)",
      iconBgColor: "#fce4ec",
      iconColor: "#c62828",
      textColor: "#1a1a1a",
      unitColor: "#888",
      borderAccent: "#ef5350",
      onClick: () => onNavigateToAdvisory?.("Overdue"),
    },
  ];

  // Render KPI Card Component
  const renderKPICard = (card: KPICard) => (
    <div
      key={card.id}
      onClick={card.onClick}
      style={{
        backgroundColor: card.backgroundColor,
        borderColor: card.borderColor,
        border: `1.5px solid ${card.borderColor}`,
        borderRadius: "10px",
        boxShadow: `0 1px 4px ${card.shadowColor.includes("rgba") ? card.shadowColor : `rgba(218, 165, 32, 0.2)`}`,
        padding: "10px",
        cursor: "pointer",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: "6px",
        textAlign: "center",
        transition: "transform 0.2s ease-in-out",
        flex: 1,
      }}
      onMouseDown={(e) => {
        if (e.currentTarget.style.transform !== undefined) {
          e.currentTarget.style.transform = "scale(0.95)";
        }
      }}
      onMouseUp={(e) => {
        if (e.currentTarget.style.transform !== undefined) {
          e.currentTarget.style.transform = "scale(1)";
        }
      }}
    >
      {/* Icon Container */}
      <div
        style={{
          backgroundColor: card.iconBgColor,
          borderRadius: "6px",
          width: "24px",
          height: "24px",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: card.iconColor,
        }}
      >
        {card.icon}
      </div>

      {/* Value and Unit */}
      <div
        style={{
          display: "flex",
          alignItems: "baseline",
          gap: "4px",
          justifyContent: "center",
        }}
      >
        <span
          style={{
            fontSize: card.id === "sown-acreage" ? "18px" : "20px",
            fontWeight: 900,
            color: card.textColor,
          }}
        >
          {typeof card.value === "string"
            ? card.value
            : card.value.toLocaleString()}
        </span>
        {card.unit && (
          <span style={{ fontSize: "10px", color: card.unitColor || "#888" }}>
            {card.unit}
          </span>
        )}
      </div>

      {/* Label */}
      <p
        style={{
          fontSize: "9px",
          fontWeight: 600,
          color: "#666",
          margin: 0,
          lineHeight: "1.2",
        }}
      >
        {card.label}
      </p>

      {/* Subtitle */}
      {card.subtitle && (
        <p
          style={{
            fontSize: "9px",
            fontWeight: 600,
            color: card.subtitleColor,
            margin: 0,
            marginTop: "2px",
          }}
        >
          {card.subtitle}
        </p>
      )}
    </div>
  );

  return (
    <div
      style={{
        backgroundColor: "#f5f5f5",
        padding: "6px 10px",
        display: "flex",
        flexDirection: "column",
        gap: "4px",
        overflowY: "auto",
        height: "100%",
      }}
    >
      {/* Section 1: Page Title */}
      <div style={{ marginBottom: "8px" }}>
        <h2
          style={{
            color: "#1a1a1a",
            fontSize: "14px",
            fontWeight: 800,
            margin: 0,
          }}
        >
          Analytics
        </h2>
        <p style={{ color: "#888", fontSize: "9px", margin: "2px 0 0 0" }}>
          Field operation kpi scorecards.
        </p>
      </div>

      {/* Section 2: Top Row - 3 Yellow Highlight Cards */}
      <div style={{ display: "flex", gap: "6px", marginBottom: "12px" }}>
        {highlightCards.map((card) => renderKPICard(card))}
      </div>

      {/* Section 3: CROP STAGES Header */}
      <div
        style={{
          color: "#2e7d32",
          fontSize: "8px",
          fontWeight: 700,
          letterSpacing: "1px",
          marginBottom: "8px",
          marginTop: "4px",
        }}
      >
        CROP STAGES
      </div>

      {/* Section 4: Crop Stage Cards - 2 Column Grid */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "5px",
          marginBottom: "12px",
        }}
      >
        {cropStageCards.map((card) => (
          <div
            key={card.id}
            onClick={card.onClick}
            style={{
              backgroundColor: card.backgroundColor,
              borderRadius: "10px",
              padding: "8px 10px",
              boxShadow: `0 1px 3px rgba(0,0,0,0.08)`,
              cursor: "pointer",
              border: `1px solid ${card.borderColor}`,
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              gap: "4px",
              transition: "transform 0.2s ease-in-out",
            }}
            onMouseDown={(e) => {
              if (e.currentTarget.style.transform !== undefined) {
                e.currentTarget.style.transform = "scale(0.98)";
              }
            }}
            onMouseUp={(e) => {
              if (e.currentTarget.style.transform !== undefined) {
                e.currentTarget.style.transform = "scale(1)";
              }
            }}
          >
            {/* Icon Container */}
            <div
              style={{
                backgroundColor: card.iconBgColor,
                borderRadius: "6px",
                width: "24px",
                height: "24px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: card.iconColor,
              }}
            >
              {card.icon}
            </div>

            {/* Value and Unit */}
            <div
              style={{ display: "flex", alignItems: "baseline", gap: "2px" }}
            >
              <span
                style={{
                  fontSize: "18px",
                  fontWeight: 800,
                  color: card.textColor,
                }}
              >
                {typeof card.value === "string"
                  ? card.value
                  : card.value.toLocaleString()}
              </span>
              {card.unit && (
                <span style={{ fontSize: "10px", color: card.unitColor }}>
                  {card.unit}
                </span>
              )}
            </div>

            {/* Label */}
            <p
              style={{
                fontSize: "9px",
                fontWeight: 600,
                color: "#666",
                margin: 0,
                lineHeight: "1.1",
              }}
            >
              {card.label}
            </p>

            {/* Subtitle */}
            {card.subtitle && (
              <p
                style={{
                  fontSize: "9px",
                  fontWeight: 600,
                  color: card.subtitleColor,
                  margin: 0,
                }}
              >
                {card.subtitle}
              </p>
            )}
          </div>
        ))}
      </div>

      {/* Section 5: ALERTS Header */}
      <div
        style={{
          color: "#2e7d32",
          fontSize: "8px",
          fontWeight: 700,
          letterSpacing: "1px",
          marginBottom: "8px",
          marginTop: "4px",
        }}
      >
        ALERTS
      </div>

      {/* Section 6: Alert Cards - 2 Column Grid */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "5px",
          marginBottom: "16px",
        }}
      >
        {alertCards.map((card) => (
          <div
            key={card.id}
            onClick={card.onClick}
            style={{
              backgroundColor: card.backgroundColor,
              borderRadius: "10px",
              padding: "8px 10px",
              boxShadow: `0 1px 3px rgba(0,0,0,0.08)`,
              cursor: "pointer",
              border: `1px solid ${card.borderColor}`,
              borderLeft: card.borderAccent
                ? `3px solid ${card.borderAccent}`
                : `1px solid ${card.borderColor}`,
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              gap: "4px",
              transition: "transform 0.2s ease-in-out",
            }}
            onMouseDown={(e) => {
              if (e.currentTarget.style.transform !== undefined) {
                e.currentTarget.style.transform = "scale(0.98)";
              }
            }}
            onMouseUp={(e) => {
              if (e.currentTarget.style.transform !== undefined) {
                e.currentTarget.style.transform = "scale(1)";
              }
            }}
          >
            {/* Icon Container */}
            <div
              style={{
                backgroundColor: card.iconBgColor,
                borderRadius: "6px",
                width: "24px",
                height: "24px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: card.iconColor,
              }}
            >
              {card.icon}
            </div>

            {/* Value and Unit */}
            <div
              style={{ display: "flex", alignItems: "baseline", gap: "2px" }}
            >
              <span
                style={{
                  fontSize: "18px",
                  fontWeight: 800,
                  color: card.textColor,
                }}
              >
                {typeof card.value === "string"
                  ? card.value
                  : card.value.toLocaleString()}
              </span>
              {card.unit && (
                <span style={{ fontSize: "10px", color: card.unitColor }}>
                  {card.unit}
                </span>
              )}
            </div>

            {/* Label */}
            <p
              style={{
                fontSize: "9px",
                fontWeight: 600,
                color: "#666",
                margin: 0,
                lineHeight: "1.1",
              }}
            >
              {card.label}
            </p>

            {/* Subtitle */}
            {card.subtitle && (
              <p
                style={{
                  fontSize: "9px",
                  fontWeight: 600,
                  color: card.subtitleColor,
                  margin: 0,
                }}
              >
                {card.subtitle}
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
