import React, { useState } from "react";
import {
  MOCK_PLOTS,
  Plot,
  MOCK_ADVISORIES,
  MOCK_GROWERS,
} from "./data/mockData";
import { Card, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "./ui/tabs";
import {
  Map as MapIcon,
  List,
  Filter,
  Search,
  Plus,
  Droplets,
  AlertTriangle,
  Bug,
  CloudRain,
  ThermometerSun,
  Sprout,
  SlidersHorizontal,
  X,
  ChevronRight,
  AlertOctagon,
  ArrowLeft,
  Download,
  Copy,
  Edit,
  Trash2,
  MoreVertical,
  Share2,
  Camera,
  Video,
  CheckCircle2,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from "./ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { AddPlotWizard } from "./AddPlotWizard";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { Checkbox } from "./ui/checkbox";
import { Separator } from "./ui/separator";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { ScrollArea } from "./ui/scroll-area";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import plotMapImage from "figma:asset/332f5dc0a96a9859a215db7d62948338a5a56cf1.png";

interface PlotTrackerProps {
  initialAuditFilter?: "all" | "audited" | "pending";
  initialStageFilter?: string;
  selectedRegion?: string;
}

export function PlotTracker({
  initialAuditFilter = "all",
  initialStageFilter = "all",
  selectedRegion = "all",
}: PlotTrackerProps = {}) {
  const [viewMode, setViewMode] = useState<"map" | "list">("list");
  const [selectedPlot, setSelectedPlot] = useState<Plot | null>(null);
  const [isAddPlotOpen, setIsAddPlotOpen] = useState(false);
  const [wizardInitialStep, setWizardInitialStep] = useState<1 | 2 | 3>(1);
  const [isPreSeasonOpen, setIsPreSeasonOpen] = useState(false);
  const [isSeasonDetailsOpen, setIsSeasonDetailsOpen] = useState(false);
  const [isHarvestDetailsOpen, setIsHarvestDetailsOpen] = useState(false);
  const [isTasksOpen, setIsTasksOpen] = useState(false);
  const [isAddTaskPageOpen, setIsAddTaskPageOpen] = useState(false);
  const [selectedStage, setSelectedStage] = useState("");
  const [isCopyPlotOpen, setIsCopyPlotOpen] = useState(false);
  const [isSeasonDetailsSaved, setIsSeasonDetailsSaved] = useState(false);
  const [isHarvestDetailsSaved, setIsHarvestDetailsSaved] = useState(false);
  const [isEditingSowingDate, setIsEditingSowingDate] = useState(false);
  const [isEditingHarvestDate, setIsEditingHarvestDate] = useState(false);
  const [copiedPlotInitialData, setCopiedPlotInitialData] = useState<any>(null);
  const [copyPlotData, setCopyPlotData] = useState({
    season: "",
    state: "",
    district: "",
    grower: "",
    plotId: "",
  });

  // Plot details form data
  const [preSeasonData, setPreSeasonData] = useState({
    soilType: "",
    previousCrop: "",
    tillageMethod: "",
    irrigationSystem: "",
  });

  // In-season Observations state - array for multiple observations
  const [observations, setObservations] = useState<
    Array<{
      id: string;
      observationType: "general" | "flag";
      flagType?: "disease" | "nutrition" | "soil-moisture";
      comment: string;
      observedDate: string;
      observedTime: string;
      criticality: "low" | "medium" | "high";
    }>
  >([]);

  const [currentObservation, setCurrentObservation] = useState({
    observationType: "general" as "general" | "flag",
    flagType: "" as "disease" | "nutrition" | "soil-moisture" | "",
    comment: "",
    observedDate: "",
    observedTime: "",
    criticality: "low" as "low" | "medium" | "high",
  });

  const [editingObservationId, setEditingObservationId] = useState<
    string | null
  >(null);

  const [harvestData, setHarvestData] = useState({
    sowingDate: "",
    harvestDate: "",
  });

  const [taskData, setTaskData] = useState({
    title: "",
    taskType: "",
    dueDate: "",
  });

  // Remarks for completed tasks
  const [isRemarksDialogOpen, setIsRemarksDialogOpen] = useState(false);
  const [currentTaskId, setCurrentTaskId] = useState<number | null>(null);
  const [remarks, setRemarks] = useState("");
  const [taskRemarks, setTaskRemarks] = useState<Record<number, string>>({});
  const [completedTasks, setCompletedTasks] = useState<Record<number, boolean>>(
    {
      3: true, // Task 3 is initially completed
    },
  );

  const handleCheckboxChange = (taskId: number, isChecked: boolean) => {
    if (!isChecked) {
      // Unchecking - just update state
      setCompletedTasks((prev) => ({ ...prev, [taskId]: false }));
    } else {
      // Checking - open remarks dialog
      setCurrentTaskId(taskId);
      setRemarks("");
      setIsRemarksDialogOpen(true);
    }
  };

  const handleRemarksSubmit = () => {
    if (currentTaskId !== null) {
      setTaskRemarks((prev) => ({ ...prev, [currentTaskId]: remarks }));
      setCompletedTasks((prev) => ({ ...prev, [currentTaskId]: true }));
      setIsRemarksDialogOpen(false);
      setCurrentTaskId(null);
      setRemarks("");
    }
  };

  // Property Photos & Videos state
  const [isMediaSectionOpen, setIsMediaSectionOpen] = useState(true);
  const [isMediaSaved, setIsMediaSaved] = useState(false);
  const [mediaEntries, setMediaEntries] = useState<
    Array<{
      id: string;
      type: "photo" | "video";
      dateCaptured: string;
      timeCaptured: string;
    }>
  >([]);
  const [currentMediaEntry, setCurrentMediaEntry] = useState({
    type: "photo" as "photo" | "video",
    dateCaptured: "",
    timeCaptured: "",
  });

  // Filter states
  const [filters, setFilters] = useState({
    grower: "all",
    assignedFieldAssistant: "all",
    state: "all",
    district: "all",
    taluka: "all",
    village: "all",
    crop: "all",
    hybrid: "all",
    currentStage: initialStageFilter,
    expectedStage: "all",
  });

  const [auditFilter, setAuditFilter] = useState<"all" | "audited" | "pending">(
    initialAuditFilter,
  );

  const activeFilterCount = [
    filters.grower !== "all",
    filters.assignedFieldAssistant !== "all",
    filters.state !== "all",
    filters.district !== "all",
    filters.taluka !== "all",
    filters.village !== "all",
    filters.crop !== "all",
    filters.hybrid !== "all",
    filters.currentStage !== "all",
    filters.expectedStage !== "all",
  ].filter(Boolean).length;

  const filteredPlots = MOCK_PLOTS.filter((plot) => {
    if (filters.grower !== "all" && plot.growerId !== filters.grower)
      return false;
    if (filters.assignedFieldAssistant !== "all") return false; // Add field assistant matching when data is available
    if (filters.state !== "all" && plot.state?.toLowerCase() !== filters.state)
      return false;
    if (
      filters.district !== "all" &&
      plot.district?.toLowerCase() !== filters.district
    )
      return false;
    if (
      filters.taluka !== "all" &&
      plot.taluka?.toLowerCase() !== filters.taluka
    )
      return false;
    if (
      filters.village !== "all" &&
      plot.village?.toLowerCase() !== filters.village
    )
      return false;
    if (filters.crop !== "all" && plot.crop?.toLowerCase() !== filters.crop)
      return false;
    if (
      filters.hybrid !== "all" &&
      plot.hybrid?.toLowerCase() !== filters.hybrid
    )
      return false;
    if (filters.currentStage !== "all" && plot.stage !== filters.currentStage)
      return false;
    if (
      filters.expectedStage !== "all" &&
      plot.expectedStage !== filters.expectedStage
    )
      return false;
    if (auditFilter !== "all" && plot.auditStatus !== auditFilter) return false;

    return true;
  });

  // Simulate Map View Component
  const MockMapView = () => (
    <div className="relative w-full h-full flex-1 bg-slate-200 overflow-hidden">
      {/* Satellite Map Background */}
      <div
        className="absolute inset-x-0 top-0 bottom-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${plotMapImage})` }}
      />

      {/* Plot Boundaries - Blue Outlines */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none">
        {/* Plot 1 - Top Left - Small Rectangle */}
        <rect
          x="50"
          y="100"
          width="120"
          height="90"
          fill="rgba(59, 130, 246, 0.15)"
          stroke="#3B82F6"
          strokeWidth="2.5"
          className="cursor-pointer hover:fill-[rgba(59,130,246,0.25)] transition-all"
          style={{ pointerEvents: "auto" }}
          onClick={() => setSelectedPlot(filteredPlots[0])}
        />

        {/* Plot 2 - Top Right - Square */}
        <rect
          x="240"
          y="90"
          width="100"
          height="100"
          fill="rgba(59, 130, 246, 0.15)"
          stroke="#3B82F6"
          strokeWidth="2.5"
          className="cursor-pointer hover:fill-[rgba(59,130,246,0.25)] transition-all"
          style={{ pointerEvents: "auto" }}
          onClick={() => setSelectedPlot(filteredPlots[1])}
        />

        {/* Plot 3 - Middle - Rectangle */}
        <rect
          x="100"
          y="250"
          width="150"
          height="100"
          fill="rgba(59, 130, 246, 0.15)"
          stroke="#3B82F6"
          strokeWidth="2.5"
          className="cursor-pointer hover:fill-[rgba(59,130,246,0.25)] transition-all"
          style={{ pointerEvents: "auto" }}
          onClick={() => setSelectedPlot(filteredPlots[2])}
        />

        {/* Plot 4 - Bottom Left - Small Square */}
        <rect
          x="40"
          y="400"
          width="90"
          height="90"
          fill="rgba(59, 130, 246, 0.15)"
          stroke="#3B82F6"
          strokeWidth="2.5"
          className="cursor-pointer hover:fill-[rgba(59,130,246,0.25)] transition-all"
          style={{ pointerEvents: "auto" }}
          onClick={() => setSelectedPlot(filteredPlots[3] || filteredPlots[0])}
        />

        {/* Plot 5 - Bottom Right - Rectangle */}
        <rect
          x="310"
          y="260"
          width="110"
          height="120"
          fill="rgba(59, 130, 246, 0.15)"
          stroke="#3B82F6"
          strokeWidth="2.5"
          className="cursor-pointer hover:fill-[rgba(59,130,246,0.25)] transition-all"
          style={{ pointerEvents: "auto" }}
          onClick={() => setSelectedPlot(filteredPlots[4] || filteredPlots[0])}
        />

        {/* Additional Small Plots */}
        {/* Plot 6 - Top Center - Small Square */}
        <rect
          x="180"
          y="50"
          width="50"
          height="50"
          fill="rgba(59, 130, 246, 0.15)"
          stroke="#3B82F6"
          strokeWidth="2.5"
          className="cursor-pointer hover:fill-[rgba(59,130,246,0.25)] transition-all"
          style={{ pointerEvents: "auto" }}
          onClick={() => setSelectedPlot(filteredPlots[0])}
        />

        {/* Plot 7 - Right Side - Small Rectangle */}
        <rect
          x="360"
          y="150"
          width="60"
          height="80"
          fill="rgba(59, 130, 246, 0.15)"
          stroke="#3B82F6"
          strokeWidth="2.5"
          className="cursor-pointer hover:fill-[rgba(59,130,246,0.25)] transition-all"
          style={{ pointerEvents: "auto" }}
          onClick={() => setSelectedPlot(filteredPlots[1])}
        />

        {/* Plot 8 - Middle Left - Small Square */}
        <rect
          x="30"
          y="280"
          width="60"
          height="60"
          fill="rgba(59, 130, 246, 0.15)"
          stroke="#3B82F6"
          strokeWidth="2.5"
          className="cursor-pointer hover:fill-[rgba(59,130,246,0.25)] transition-all"
          style={{ pointerEvents: "auto" }}
          onClick={() => setSelectedPlot(filteredPlots[2])}
        />
      </svg>

      {/* Search Bar Overlay */}
      <div className="absolute top-4 left-4 right-4 z-10">
        <div className="relative bg-white rounded-lg shadow-lg">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
          <Input
            placeholder="Search plots by ID or Grower Name"
            className="pl-10 h-11 border-0 text-sm"
          />
        </div>
      </div>

      {/* Map Controls */}
      <div className="absolute bottom-4 right-4 flex flex-col gap-2 z-10">
        <Button
          variant="secondary"
          size="icon"
          className="bg-white shadow-lg h-10 w-10"
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );

  // If add task page is open, show the full page form
  if (isAddTaskPageOpen) {
    return (
      <div className="space-y-4 h-full flex flex-col">
        {/* Header with Back Button */}
        <div className="flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => {
              setIsAddTaskPageOpen(false);
              setTaskData({ title: "", taskType: "", dueDate: "" });
            }}
          >
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex-1">
            <h2 className="font-bold">Add Task</h2>
            <p className="text-sm text-slate-500">
              Create a new task for this plot
            </p>
          </div>
        </div>

        {/* Add Task Form */}
        <Card className="flex-1">
          <CardContent className="p-4 space-y-4">
            <div className="space-y-2">
              <Label>Title</Label>
              <Input
                placeholder="Enter task title"
                value={taskData.title}
                onChange={(e) =>
                  setTaskData({ ...taskData, title: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Task Type</Label>
              <Select
                value={taskData.taskType}
                onValueChange={(v) => setTaskData({ ...taskData, taskType: v })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select task type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="irrigation">Irrigation</SelectItem>
                  <SelectItem value="monitoring">Monitoring</SelectItem>
                  <SelectItem value="analysis">Analysis</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="fertilization">Fertilization</SelectItem>
                  <SelectItem value="pest-control">Pest Control</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Due Date</Label>
              <Input
                type="date"
                value={taskData.dueDate}
                onChange={(e) =>
                  setTaskData({ ...taskData, dueDate: e.target.value })
                }
              />
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="flex gap-2 pt-2">
          <Button
            variant="outline"
            className="flex-1"
            onClick={() => {
              setIsAddTaskPageOpen(false);
              setTaskData({ title: "", taskType: "", dueDate: "" });
            }}
          >
            Cancel
          </Button>
          <Button
            className="flex-1"
            onClick={() => {
              // Save task logic here
              setIsAddTaskPageOpen(false);
              setTaskData({ title: "", taskType: "", dueDate: "" });
            }}
            disabled={
              !taskData.title || !taskData.taskType || !taskData.dueDate
            }
          >
            Save Task
          </Button>
        </div>
      </div>
    );
  }

  // If a plot is selected, show the full page details view
  if (selectedPlot) {
    return (
      <div className="space-y-4 h-full flex flex-col">
        {/* Simplified Header with Back Button, Plot ID, and Grower */}
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setSelectedPlot(null)}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex-1 min-w-0">
            <h2 className="font-bold font-mono truncate">{selectedPlot.id}</h2>
            <p className="text-sm text-slate-500 truncate">
              {selectedPlot.growerName}
            </p>
          </div>
          <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0">
            <Share2 className="h-4 w-4" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 flex-shrink-0"
              >
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Edit className="h-4 w-4 mr-2" />
                Edit
              </DropdownMenuItem>
              <DropdownMenuItem className="text-red-600">
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </DropdownMenuItem>
              <DropdownMenuItem>
                <AlertOctagon className="h-4 w-4 mr-2" />
                Report An Issue
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Tabs for Details and Advisory Tasks */}
        <Tabs defaultValue="details" className="flex-1 flex flex-col">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger
              value="details"
              className="data-[state=active]:bg-[#4CAF50] data-[state=active]:text-white"
            >
              Details
            </TabsTrigger>
            <TabsTrigger
              value="advisory-tasks"
              className="data-[state=active]:bg-[#4CAF50] data-[state=active]:text-white"
            >
              Advisory Tasks
            </TabsTrigger>
          </TabsList>

          {/* Details Tab */}
          <TabsContent
            value="details"
            className="flex-1 overflow-y-auto space-y-4 mt-4 pb-20"
          >
            {/* Plot Details */}
            <Card>
              <CardContent className="p-4 space-y-4">
                <h3 className="font-semibold text-slate-900">Plot Details</h3>
                <div className="grid grid-cols-2 gap-x-4 gap-y-3 text-sm">
                  <div>
                    <p className="text-xs text-slate-500">Grower</p>
                    <p className="font-medium text-slate-900">
                      {selectedPlot.growerName}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">
                      Assigned Field Assistant
                    </p>
                    <p className="font-medium text-slate-900">Rajiv Sharma</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">State</p>
                    <p className="font-medium text-slate-900">Punjab</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">District</p>
                    <p className="font-medium text-slate-900">Amritsar</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Taluka</p>
                    <p className="font-medium text-slate-900">Beas</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Village</p>
                    <p className="font-medium text-slate-900">
                      {selectedPlot.village}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Plot Purpose</p>
                    <p className="font-medium text-slate-900">All Hybrids</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Irrigation Method</p>
                    <p className="font-medium text-slate-900">Drip</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Isolation Observed</p>
                    <p className="font-medium text-slate-900">Yes</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Crop</p>
                    <p className="font-medium text-slate-900">
                      {selectedPlot.crop}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Hybrid Type</p>
                    <p className="font-medium text-slate-900">
                      {selectedPlot.hybrid}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Estimated Acreage</p>
                    <p className="font-medium text-slate-900">
                      {selectedPlot.acreage}
                    </p>
                  </div>
                </div>

                {/* Divider */}
                <Separator className="my-4" />

                {/* Sowing Date Field */}
                <div className="space-y-2">
                  <Label>Sowing Date</Label>
                  {!harvestData.sowingDate && !isEditingSowingDate && (
                    <Button
                      variant="outline"
                      className="w-full gap-2 justify-start h-10"
                      onClick={() => setIsEditingSowingDate(true)}
                    >
                      <Plus className="h-4 w-4" /> Add
                    </Button>
                  )}

                  {harvestData.sowingDate && !isEditingSowingDate && (
                    <div className="flex items-center justify-between p-3 bg-slate-50 rounded-md border">
                      <p className="font-medium text-slate-900">
                        {new Date(harvestData.sowingDate).toLocaleDateString()}
                      </p>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7"
                        onClick={() => setIsEditingSowingDate(true)}
                      >
                        <Edit className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  )}

                  {isEditingSowingDate && (
                    <div className="space-y-2">
                      <Input
                        type="date"
                        value={harvestData.sowingDate}
                        onChange={(e) =>
                          setHarvestData({
                            ...harvestData,
                            sowingDate: e.target.value,
                          })
                        }
                      />
                      <div className="flex justify-end gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setIsEditingSowingDate(false);
                            if (!harvestData.sowingDate) {
                              setHarvestData({
                                ...harvestData,
                                sowingDate: "",
                              });
                            }
                          }}
                        >
                          Cancel
                        </Button>
                        <Button
                          size="sm"
                          className="bg-[#4CAF50] hover:bg-[#388E3C]"
                          onClick={() => setIsEditingSowingDate(false)}
                        >
                          Save
                        </Button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Complete Weeks Field - Only shows after sowing date is saved */}
                {harvestData.sowingDate && (
                  <div className="space-y-2">
                    <Label>Complete Weeks</Label>
                    <Input
                      type="text"
                      value={`${Math.floor((new Date().getTime() - new Date(harvestData.sowingDate).getTime()) / (1000 * 60 * 60 * 24 * 7))} weeks`}
                      readOnly
                      disabled
                      className="bg-slate-50"
                    />
                  </div>
                )}

                {/* Harvest Date Field - Only shows after sowing date is saved */}
                {harvestData.sowingDate && (
                  <div className="space-y-2">
                    <Label>Harvest Date</Label>
                    {!harvestData.harvestDate && !isEditingHarvestDate && (
                      <Button
                        variant="outline"
                        className="w-full gap-2 justify-start h-10"
                        onClick={() => setIsEditingHarvestDate(true)}
                      >
                        <Plus className="h-4 w-4" /> Add
                      </Button>
                    )}

                    {harvestData.harvestDate && !isEditingHarvestDate && (
                      <div className="flex items-center justify-between p-3 bg-slate-50 rounded-md border">
                        <p className="font-medium text-slate-900">
                          {new Date(
                            harvestData.harvestDate,
                          ).toLocaleDateString()}
                        </p>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-7 w-7"
                          onClick={() => setIsEditingHarvestDate(true)}
                        >
                          <Edit className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    )}

                    {isEditingHarvestDate && (
                      <div className="space-y-2">
                        <Input
                          type="date"
                          value={harvestData.harvestDate}
                          onChange={(e) =>
                            setHarvestData({
                              ...harvestData,
                              harvestDate: e.target.value,
                            })
                          }
                        />
                        <div className="flex justify-end gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setIsEditingHarvestDate(false);
                              if (!harvestData.harvestDate) {
                                setHarvestData({
                                  ...harvestData,
                                  harvestDate: "",
                                });
                              }
                            }}
                          >
                            Cancel
                          </Button>
                          <Button
                            size="sm"
                            className="bg-[#4CAF50] hover:bg-[#388E3C]"
                            onClick={() => setIsEditingHarvestDate(false)}
                          >
                            Save
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Plot Mapping */}
            <Card>
              <CardContent className="p-4 space-y-4">
                <h3 className="font-semibold text-slate-900">Plot Mapping</h3>

                {selectedPlot?.auditStatus === "pending" ? (
                  <>
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <Badge
                          variant="outline"
                          className="bg-slate-100 text-slate-600 border-slate-300"
                        >
                          Audit Pending
                        </Badge>
                      </div>
                      <Button
                        className="w-full gap-2 bg-[#4CAF50] hover:bg-[#45a049]"
                        onClick={() => {
                          setSelectedPlot(null);
                          setWizardInitialStep(2);
                          setIsAddPlotOpen(true);
                        }}
                      >
                        <CheckCircle2 className="h-4 w-4" /> Start Audit
                      </Button>
                    </div>
                  </>
                ) : (
                  <div>
                    <p className="text-xs text-slate-500 mb-2">
                      Audited Acreage
                    </p>
                    <p className="text-2xl font-bold text-[#4CAF50]">
                      2.3 acres
                    </p>
                  </div>
                )}

                {selectedPlot?.auditStatus !== "pending" && (
                  <div>
                    <p className="text-xs text-slate-500 mb-2">
                      Plot Preview On Map
                    </p>
                    <div className="w-full h-48 bg-slate-100 rounded-lg overflow-hidden border border-slate-200">
                      <ImageWithFallback
                        src={plotMapImage}
                        alt="Satellite view of plot"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* In-season Observations */}
            <Card>
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-slate-900">
                    In-season Observations
                  </h3>
                </div>

                {/* List of saved observations */}
                {observations.length > 0 && !isSeasonDetailsOpen && (
                  <div className="space-y-3">
                    {observations.map((obs) => (
                      <Card key={obs.id} className="border border-slate-200">
                        <CardContent className="p-3">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 space-y-2">
                              <div className="flex items-center gap-2">
                                <Badge
                                  variant={
                                    obs.observationType === "flag"
                                      ? "destructive"
                                      : "secondary"
                                  }
                                  className="text-xs"
                                >
                                  {obs.observationType === "flag"
                                    ? "Flag"
                                    : "General"}
                                </Badge>
                                {obs.observationType === "flag" &&
                                  obs.flagType && (
                                    <Badge
                                      variant="outline"
                                      className="text-xs capitalize"
                                    >
                                      {obs.flagType.replace("-", " ")}
                                    </Badge>
                                  )}
                                <Badge
                                  variant="outline"
                                  className={`text-xs capitalize ${
                                    obs.criticality === "high"
                                      ? "border-red-300 text-red-700 bg-red-50"
                                      : obs.criticality === "medium"
                                        ? "border-yellow-300 text-yellow-700 bg-yellow-50"
                                        : "border-green-300 text-green-700 bg-green-50"
                                  }`}
                                >
                                  {obs.criticality}
                                </Badge>
                              </div>
                              <p className="text-sm text-slate-700">
                                {obs.comment}
                              </p>
                              <div className="flex items-center gap-3 text-xs text-slate-500">
                                <span>
                                  {new Date(
                                    obs.observedDate,
                                  ).toLocaleDateString()}
                                </span>
                                <span>{obs.observedTime}</span>
                              </div>
                            </div>
                            <div className="flex gap-1">
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7"
                                onClick={() => {
                                  setEditingObservationId(obs.id);
                                  setCurrentObservation({
                                    observationType: obs.observationType,
                                    flagType: obs.flagType || "",
                                    comment: obs.comment,
                                    observedDate: obs.observedDate,
                                    observedTime: obs.observedTime,
                                    criticality: obs.criticality,
                                  });
                                  setIsSeasonDetailsOpen(true);
                                }}
                              >
                                <Edit className="h-3.5 w-3.5" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                className="h-7 w-7 text-red-600 hover:text-red-700 hover:bg-red-50"
                                onClick={() => {
                                  setObservations(
                                    observations.filter((o) => o.id !== obs.id),
                                  );
                                }}
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}

                    <Button
                      className="w-full gap-2"
                      onClick={() => {
                        setIsSeasonDetailsOpen(true);
                        setEditingObservationId(null);
                        setCurrentObservation({
                          observationType: "general",
                          flagType: "",
                          comment: "",
                          observedDate: "",
                          observedTime: "",
                          criticality: "low",
                        });
                      }}
                    >
                      <Plus className="h-4 w-4" /> Add Observation
                    </Button>
                  </div>
                )}

                {observations.length === 0 && !isSeasonDetailsOpen && (
                  <Button
                    className="w-full gap-2"
                    onClick={() => setIsSeasonDetailsOpen(true)}
                  >
                    <Plus className="h-4 w-4" /> Add Observation
                  </Button>
                )}

                {isSeasonDetailsOpen && (
                  <div className="space-y-4 pt-4 border-t">
                    <div className="space-y-2">
                      <Label>Observation Type</Label>
                      <Select
                        value={currentObservation.observationType}
                        onValueChange={(v: "general" | "flag") =>
                          setCurrentObservation({
                            ...currentObservation,
                            observationType: v,
                            flagType:
                              v === "general"
                                ? ""
                                : currentObservation.flagType,
                          })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="general">General</SelectItem>
                          <SelectItem value="flag">Flag</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {currentObservation.observationType === "flag" && (
                      <div className="space-y-2">
                        <Label>Flag Type</Label>
                        <Select
                          value={currentObservation.flagType}
                          onValueChange={(v) =>
                            setCurrentObservation({
                              ...currentObservation,
                              flagType: v as
                                | "disease"
                                | "nutrition"
                                | "soil-moisture",
                            })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select flag type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="disease">Disease</SelectItem>
                            <SelectItem value="nutrition">Nutrition</SelectItem>
                            <SelectItem value="soil-moisture">
                              Soil Moisture
                            </SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    <div className="space-y-2">
                      <Label>Comment</Label>
                      <Textarea
                        placeholder="Add your observation comment..."
                        rows={3}
                        value={currentObservation.comment}
                        onChange={(e) =>
                          setCurrentObservation({
                            ...currentObservation,
                            comment: e.target.value,
                          })
                        }
                      />
                    </div>

                    <div className="space-y-2">
                      <Label>Add Media</Label>
                      <Button variant="outline" className="w-full gap-2">
                        <Camera className="h-4 w-4" />
                        Upload Photo/Video
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Observed On (Date)</Label>
                        <Input
                          type="date"
                          value={currentObservation.observedDate}
                          onChange={(e) =>
                            setCurrentObservation({
                              ...currentObservation,
                              observedDate: e.target.value,
                            })
                          }
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Time</Label>
                        <Input
                          type="time"
                          value={currentObservation.observedTime}
                          onChange={(e) =>
                            setCurrentObservation({
                              ...currentObservation,
                              observedTime: e.target.value,
                            })
                          }
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Criticality</Label>
                      <Select
                        value={currentObservation.criticality}
                        onValueChange={(v: "low" | "medium" | "high") =>
                          setCurrentObservation({
                            ...currentObservation,
                            criticality: v,
                          })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <Button
                        variant="outline"
                        onClick={() => {
                          setIsSeasonDetailsOpen(false);
                          setEditingObservationId(null);
                          setCurrentObservation({
                            observationType: "general",
                            flagType: "",
                            comment: "",
                            observedDate: "",
                            observedTime: "",
                            criticality: "low",
                          });
                        }}
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={() => {
                          if (editingObservationId) {
                            // Update existing observation
                            setObservations(
                              observations.map((obs) =>
                                obs.id === editingObservationId
                                  ? {
                                      ...obs,
                                      observationType:
                                        currentObservation.observationType,
                                      flagType: currentObservation.flagType as
                                        | "disease"
                                        | "nutrition"
                                        | "soil-moisture"
                                        | undefined,
                                      comment: currentObservation.comment,
                                      observedDate:
                                        currentObservation.observedDate,
                                      observedTime:
                                        currentObservation.observedTime,
                                      criticality:
                                        currentObservation.criticality,
                                    }
                                  : obs,
                              ),
                            );
                          } else {
                            // Add new observation
                            const newObservation = {
                              id: Date.now().toString(),
                              observationType:
                                currentObservation.observationType,
                              flagType:
                                currentObservation.observationType === "flag"
                                  ? (currentObservation.flagType as
                                      | "disease"
                                      | "nutrition"
                                      | "soil-moisture")
                                  : undefined,
                              comment: currentObservation.comment,
                              observedDate: currentObservation.observedDate,
                              observedTime: currentObservation.observedTime,
                              criticality: currentObservation.criticality,
                            };
                            setObservations([...observations, newObservation]);
                          }
                          setIsSeasonDetailsOpen(false);
                          setEditingObservationId(null);
                          setCurrentObservation({
                            observationType: "general",
                            flagType: "",
                            comment: "",
                            observedDate: "",
                            observedTime: "",
                            criticality: "low",
                          });
                        }}
                        disabled={
                          !currentObservation.comment ||
                          !currentObservation.observedDate ||
                          !currentObservation.observedTime ||
                          (currentObservation.observationType === "flag" &&
                            !currentObservation.flagType)
                        }
                      >
                        {editingObservationId
                          ? "Update Observation"
                          : "Save Observation"}
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Advisory Tasks Tab */}
          <TabsContent
            value="advisory-tasks"
            className="flex-1 overflow-y-auto space-y-4 mt-4 pb-20"
          >
            {/* Tasks */}
            <Card>
              <CardContent className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-slate-900">Tasks</h3>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-8 w-8"
                    onClick={() => setIsAddTaskPageOpen(true)}
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>

                {/* Filters and Search */}
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1">
                    <Button size="sm" variant="outline" className="h-7 text-xs">
                      All
                    </Button>
                    <Button size="sm" variant="ghost" className="h-7 text-xs">
                      Overdue
                    </Button>
                    <Button size="sm" variant="ghost" className="h-7 text-xs">
                      Pending
                    </Button>
                    <Button size="sm" variant="ghost" className="h-7 text-xs">
                      Completed
                    </Button>
                  </div>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-7 w-7 ml-auto"
                  >
                    <Search className="h-3.5 w-3.5" />
                  </Button>
                </div>

                {/* Task List */}
                <div className="space-y-2">
                  {/* Task 1 */}
                  <Card className="border border-slate-200">
                    <CardContent className="p-3">
                      <div className="flex items-start gap-3">
                        <Checkbox
                          className="mt-0.5"
                          checked={completedTasks[1]}
                          onCheckedChange={(checked) =>
                            handleCheckboxChange(1, checked === true)
                          }
                        />
                        <div className="flex-1 min-w-0">
                          <p
                            className={`font-medium text-sm ${completedTasks[1] ? "line-through text-slate-400" : ""}`}
                          >
                            Apply Fertilizer
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              Irrigation
                            </Badge>
                            <span
                              className={`text-xs ${completedTasks[1] ? "text-slate-400" : "text-slate-500"}`}
                            >
                              Due: Dec 10, 2024
                            </span>
                          </div>
                          {taskRemarks[1] && (
                            <div className="mt-2 p-2 bg-slate-50 rounded-md border border-slate-200">
                              <p className="text-xs font-medium text-slate-700">
                                Remarks:
                              </p>
                              <p className="text-xs text-slate-600 mt-1">
                                {taskRemarks[1]}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Task 2 */}
                  <Card className="border border-slate-200">
                    <CardContent className="p-3">
                      <div className="flex items-start gap-3">
                        <Checkbox
                          className="mt-0.5"
                          checked={completedTasks[2]}
                          onCheckedChange={(checked) =>
                            handleCheckboxChange(2, checked === true)
                          }
                        />
                        <div className="flex-1 min-w-0">
                          <p
                            className={`font-medium text-sm ${completedTasks[2] ? "line-through text-slate-400" : ""}`}
                          >
                            Pest Inspection
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              Monitoring
                            </Badge>
                            <span
                              className={`text-xs ${completedTasks[2] ? "text-slate-400" : "text-slate-500"}`}
                            >
                              Due: Dec 12, 2024
                            </span>
                          </div>
                          {taskRemarks[2] && (
                            <div className="mt-2 p-2 bg-slate-50 rounded-md border border-slate-200">
                              <p className="text-xs font-medium text-slate-700">
                                Remarks:
                              </p>
                              <p className="text-xs text-slate-600 mt-1">
                                {taskRemarks[2]}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Task 3 */}
                  <Card className="border border-slate-200">
                    <CardContent className="p-3">
                      <div className="flex items-start gap-3">
                        <Checkbox
                          className="mt-0.5"
                          checked={completedTasks[3]}
                          onCheckedChange={(checked) =>
                            handleCheckboxChange(3, checked === true)
                          }
                        />
                        <div className="flex-1 min-w-0">
                          <p
                            className={`font-medium text-sm ${completedTasks[3] ? "line-through text-slate-400" : ""}`}
                          >
                            Soil Testing
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              Analysis
                            </Badge>
                            <span
                              className={`text-xs ${completedTasks[3] ? "text-slate-400" : "text-slate-500"}`}
                            >
                              Due: Dec 5, 2024
                            </span>
                          </div>
                          {taskRemarks[3] && (
                            <div className="mt-2 p-2 bg-slate-50 rounded-md border border-slate-200">
                              <p className="text-xs font-medium text-slate-700">
                                Remarks:
                              </p>
                              <p className="text-xs text-slate-600 mt-1">
                                {taskRemarks[3]}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Task 4 */}
                  <Card className="border border-slate-200">
                    <CardContent className="p-3">
                      <div className="flex items-start gap-3">
                        <Checkbox
                          className="mt-0.5"
                          checked={completedTasks[4]}
                          onCheckedChange={(checked) =>
                            handleCheckboxChange(4, checked === true)
                          }
                        />
                        <div className="flex-1 min-w-0">
                          <p
                            className={`font-medium text-sm ${completedTasks[4] ? "line-through text-slate-400" : ""}`}
                          >
                            Weed Control
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-xs">
                              Maintenance
                            </Badge>
                            <span
                              className={`text-xs ${completedTasks[4] ? "text-slate-400" : "text-slate-500"}`}
                            >
                              Due: Dec 15, 2024
                            </span>
                          </div>
                          {taskRemarks[4] && (
                            <div className="mt-2 p-2 bg-slate-50 rounded-md border border-slate-200">
                              <p className="text-xs font-medium text-slate-700">
                                Remarks:
                              </p>
                              <p className="text-xs text-slate-600 mt-1">
                                {taskRemarks[4]}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Add Task Form */}
                {isTasksOpen && (
                  <div className="space-y-4 pt-4 border-t">
                    <div className="space-y-2">
                      <Label>Task Title</Label>
                      <Input placeholder="Enter task title" />
                    </div>
                    <div className="space-y-2">
                      <Label>Task Type</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select task type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="irrigation">Irrigation</SelectItem>
                          <SelectItem value="monitoring">Monitoring</SelectItem>
                          <SelectItem value="analysis">Analysis</SelectItem>
                          <SelectItem value="maintenance">
                            Maintenance
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Due Date</Label>
                      <Input type="date" />
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                      <Button
                        variant="outline"
                        onClick={() => setIsTasksOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button onClick={() => setIsTasksOpen(false)}>
                        Save Task
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Add Remarks Full Page */}
        {isRemarksDialogOpen && (
          <div className="absolute inset-0 z-50 bg-white flex flex-col animate-in fade-in slide-in-from-bottom duration-300">
            {/* Green Header */}
            <div className="px-4 py-3 border-b bg-[rgb(76,175,80)] text-white flex justify-between items-center">
              <div className="flex-1">
                <h2 className="text-lg font-bold leading-none">Add Remarks</h2>
                <p className="text-xs mt-1 text-white/80">
                  Add completion remarks for this task
                </p>
              </div>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-y-auto p-4 pb-6 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label
                    htmlFor="remarks-plot"
                    className="text-base font-medium"
                  >
                    Remarks <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="remarks-plot"
                    placeholder="Enter your remarks here..."
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    rows={6}
                    className="resize-none text-base"
                  />
                </div>
              </div>
            </div>

            {/* Footer with Buttons */}
            <div className="p-4 border-t bg-white">
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1 h-10 text-sm"
                  onClick={() => {
                    setIsRemarksDialogOpen(false);
                    setCurrentTaskId(null);
                    setRemarks("");
                  }}
                >
                  Cancel
                </Button>
                <Button
                  className="flex-1 h-10 bg-[#4CAF50] hover:bg-[#388E3C] text-sm"
                  onClick={handleRemarksSubmit}
                  disabled={!remarks.trim()}
                >
                  Submit
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="gap-3 h-full flex flex-col pb-6">
      {/* Top Bar */}
      <div className="flex justify-between items-center gap-4">
        <div>
          <h2 className="text-xl font-bold">Plot Tracker</h2>
          <p className="text-sm text-slate-500">{filteredPlots.length} plots</p>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon">
            <Download className="h-4 w-4" />
          </Button>

          <Popover>
            <PopoverTrigger asChild>
              <Button size="icon">
                <Plus className="h-4 w-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-56 p-2" align="end">
              <div className="space-y-1">
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-2"
                  onClick={() => {
                    setWizardInitialStep(1);
                    setIsAddPlotOpen(true);
                  }}
                >
                  <Plus className="h-4 w-4" />
                  New Plot
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start gap-2"
                  onClick={() => {
                    setIsCopyPlotOpen(true);
                  }}
                >
                  <Copy className="h-4 w-4" />
                  Copy From Existing Plot
                </Button>
              </div>
            </PopoverContent>
          </Popover>

          <AddPlotWizard
            isOpen={isAddPlotOpen}
            onClose={() => {
              setIsAddPlotOpen(false);
              setCopiedPlotInitialData(null);
              setWizardInitialStep(1);
            }}
            initialData={copiedPlotInitialData}
            selectedRegion={selectedRegion}
            initialStep={wizardInitialStep}
          />

          {/* Copy Plot Dialog */}
          <Dialog open={isCopyPlotOpen} onOpenChange={setIsCopyPlotOpen}>
            <DialogContent
              className="max-w-full h-full m-0 rounded-none p-0 flex flex-col"
              hideCloseButton
            >
              <DialogTitle className="sr-only">
                Copy From Existing Plot
              </DialogTitle>
              <DialogDescription className="sr-only">
                Select an existing plot to copy data from
              </DialogDescription>

              {/* Green Header matching AddPlotWizard */}
              <div className="px-4 py-3 border-b bg-[rgb(76,175,80)] text-white flex justify-between items-center flex-shrink-0">
                <div className="flex-1">
                  <h2 className="text-lg font-bold leading-none">
                    Copy From Existing Plot
                  </h2>
                  <p className="text-xs text-[rgb(255,255,255)] mt-1">
                    Select an existing plot to copy data from
                  </p>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-4 pb-6 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label>Season</Label>
                    <Select
                      value={copyPlotData.season}
                      onValueChange={(v) =>
                        setCopyPlotData({ ...copyPlotData, season: v })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select season" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="2024-kharif">
                          2024 - Kharif
                        </SelectItem>
                        <SelectItem value="2024-rabi">2024 - Rabi</SelectItem>
                        <SelectItem value="2023-kharif">
                          2023 - Kharif
                        </SelectItem>
                        <SelectItem value="2023-rabi">2023 - Rabi</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>State</Label>
                    <Select
                      value={copyPlotData.state}
                      onValueChange={(v) =>
                        setCopyPlotData({
                          ...copyPlotData,
                          state: v,
                          district: "",
                          grower: "",
                          plotId: "",
                        })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select state" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="punjab">Punjab</SelectItem>
                        <SelectItem value="haryana">Haryana</SelectItem>
                        <SelectItem value="maharashtra">Maharashtra</SelectItem>
                        <SelectItem value="karnataka">Karnataka</SelectItem>
                        <SelectItem value="uttar-pradesh">
                          Uttar Pradesh
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>District</Label>
                    <Select
                      value={copyPlotData.district}
                      onValueChange={(v) =>
                        setCopyPlotData({
                          ...copyPlotData,
                          district: v,
                          grower: "",
                          plotId: "",
                        })
                      }
                      disabled={!copyPlotData.state}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select district" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="amritsar">Amritsar</SelectItem>
                        <SelectItem value="ludhiana">Ludhiana</SelectItem>
                        <SelectItem value="jalandhar">Jalandhar</SelectItem>
                        <SelectItem value="patiala">Patiala</SelectItem>
                        <SelectItem value="bathinda">Bathinda</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Grower</Label>
                    <Select
                      value={copyPlotData.grower}
                      onValueChange={(v) =>
                        setCopyPlotData({
                          ...copyPlotData,
                          grower: v,
                          plotId: "",
                        })
                      }
                      disabled={!copyPlotData.district}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select grower" />
                      </SelectTrigger>
                      <SelectContent>
                        {MOCK_GROWERS.map((grower) => (
                          <SelectItem key={grower.id} value={grower.id}>
                            {grower.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Plot ID</Label>
                    <Select
                      value={copyPlotData.plotId}
                      onValueChange={(v) =>
                        setCopyPlotData({ ...copyPlotData, plotId: v })
                      }
                      disabled={!copyPlotData.grower}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select plot" />
                      </SelectTrigger>
                      <SelectContent>
                        {MOCK_PLOTS.filter(
                          (plot) => plot.growerId === copyPlotData.grower,
                        ).map((plot) => (
                          <SelectItem key={plot.id} value={plot.id}>
                            {plot.id}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              {/* Footer with same button styling as AddPlotWizard */}
              <div className="p-4 border-t bg-white flex-shrink-0">
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    className="text-sm px-3"
                    onClick={() => {
                      setIsCopyPlotOpen(false);
                      setCopyPlotData({
                        season: "",
                        state: "",
                        district: "",
                        grower: "",
                        plotId: "",
                      });
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    className="flex-1 bg-[#4CAF50] hover:bg-[#388E3C] text-sm"
                    onClick={() => {
                      // Find the selected plot and prepare its data for pre-filling
                      const selectedPlot = MOCK_PLOTS.find(
                        (plot) => plot.id === copyPlotData.plotId,
                      );
                      if (selectedPlot) {
                        setCopiedPlotInitialData({
                          grower: selectedPlot.growerId,
                          fieldAssistant: "rajiv-sharma",
                          state: selectedPlot.state,
                          district: selectedPlot.district,
                          taluka: "taluka-x",
                          village: "village-alpha",
                          hybrid: "super-99",
                          purpose: "all_hybrids",
                          irrigation:
                            selectedPlot.irrigationMethod?.toLowerCase() ||
                            "drip",
                          planting: "manual",
                          isolationVerified: "yes",
                          crop: selectedPlot.crop?.toLowerCase() || "corn",
                          sowingDate: "",
                          estimatedAcreage:
                            selectedPlot.acreage?.toString() || "",
                        });
                      }
                      setIsCopyPlotOpen(false);
                      setIsAddPlotOpen(true);
                      setCopyPlotData({
                        season: "",
                        state: "",
                        district: "",
                        grower: "",
                        plotId: "",
                      });
                    }}
                  >
                    Proceed
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Expanded Filters Bar */}
      {viewMode === "list" && (
        <div className="flex gap-3 items-center justify-between bg-white p-3 rounded-lg border shadow-sm">
          {/* Filter Icon with Popover */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="h-8 gap-2">
                <Filter className="h-4 w-4" />
                {activeFilterCount > 0 && (
                  <Badge variant="secondary" className="h-4 px-1.5 text-[10px]">
                    {activeFilterCount}
                  </Badge>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80 p-0" align="start">
              <div className="p-3 bg-slate-50 border-b">
                <h4 className="font-medium text-sm">Filters</h4>
                <p className="text-xs text-slate-500">
                  Filter plots by location and assignment
                </p>
              </div>
              <ScrollArea className="h-[400px]">
                <div className="p-4 space-y-4">
                  {/* Grower Filter */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Grower</Label>
                    <Select
                      value={filters.grower}
                      onValueChange={(v) =>
                        setFilters({ ...filters, grower: v })
                      }
                    >
                      <SelectTrigger className="h-8 text-xs">
                        <SelectValue placeholder="Select grower" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Growers</SelectItem>
                        {MOCK_GROWERS.map((grower) => (
                          <SelectItem key={grower.id} value={grower.id}>
                            {grower.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  {/* Assigned Field Assistant Filter */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">
                      Assigned Field Assistant
                    </Label>
                    <Select
                      value={filters.assignedFieldAssistant}
                      onValueChange={(v) =>
                        setFilters({ ...filters, assignedFieldAssistant: v })
                      }
                    >
                      <SelectTrigger className="h-8 text-xs">
                        <SelectValue placeholder="Select field assistant" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">
                          All Field Assistants
                        </SelectItem>
                        <SelectItem value="rajiv-sharma">
                          Rajiv Sharma
                        </SelectItem>
                        <SelectItem value="priya-patel">Priya Patel</SelectItem>
                        <SelectItem value="amit-singh">Amit Singh</SelectItem>
                        <SelectItem value="neha-gupta">Neha Gupta</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  {/* State Filter */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">State</Label>
                    <Select
                      value={filters.state}
                      onValueChange={(v) =>
                        setFilters({ ...filters, state: v })
                      }
                    >
                      <SelectTrigger className="h-8 text-xs">
                        <SelectValue placeholder="Select state" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All States</SelectItem>
                        <SelectItem value="punjab">Punjab</SelectItem>
                        <SelectItem value="haryana">Haryana</SelectItem>
                        <SelectItem value="maharashtra">Maharashtra</SelectItem>
                        <SelectItem value="karnataka">Karnataka</SelectItem>
                        <SelectItem value="uttar pradesh">
                          Uttar Pradesh
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  {/* District Filter */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">District</Label>
                    <Select
                      value={filters.district}
                      onValueChange={(v) =>
                        setFilters({ ...filters, district: v })
                      }
                    >
                      <SelectTrigger className="h-8 text-xs">
                        <SelectValue placeholder="Select district" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Districts</SelectItem>
                        <SelectItem value="amritsar">Amritsar</SelectItem>
                        <SelectItem value="ludhiana">Ludhiana</SelectItem>
                        <SelectItem value="jalandhar">Jalandhar</SelectItem>
                        <SelectItem value="patiala">Patiala</SelectItem>
                        <SelectItem value="bathinda">Bathinda</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  {/* Taluka Filter */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Taluka</Label>
                    <Select
                      value={filters.taluka}
                      onValueChange={(v) =>
                        setFilters({ ...filters, taluka: v })
                      }
                    >
                      <SelectTrigger className="h-8 text-xs">
                        <SelectValue placeholder="Select taluka" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Talukas</SelectItem>
                        <SelectItem value="beas">Beas</SelectItem>
                        <SelectItem value="ajnala">Ajnala</SelectItem>
                        <SelectItem value="majitha">Majitha</SelectItem>
                        <SelectItem value="tarn-taran">Tarn Taran</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  {/* Village Filter */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Village</Label>
                    <Select
                      value={filters.village}
                      onValueChange={(v) =>
                        setFilters({ ...filters, village: v })
                      }
                    >
                      <SelectTrigger className="h-8 text-xs">
                        <SelectValue placeholder="Select village" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Villages</SelectItem>
                        <SelectItem value="rampur">Rampur</SelectItem>
                        <SelectItem value="sultanpur">Sultanpur</SelectItem>
                        <SelectItem value="khanna">Khanna</SelectItem>
                        <SelectItem value="moga">Moga</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  {/* Current Stage Filter */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Current Stage</Label>
                    <Select
                      value={filters.currentStage}
                      onValueChange={(v) =>
                        setFilters({ ...filters, currentStage: v })
                      }
                    >
                      <SelectTrigger className="h-8 text-xs">
                        <SelectValue placeholder="Select current stage" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Stages</SelectItem>
                        <SelectItem value="Sowing">Sowing</SelectItem>
                        <SelectItem value="Vegetative">Vegetative</SelectItem>
                        <SelectItem value="Detassling">Detassling</SelectItem>
                        <SelectItem value="Transplanting">
                          Transplanting
                        </SelectItem>
                        <SelectItem value="PPI">PPI</SelectItem>
                        <SelectItem value="Flowering">Flowering</SelectItem>
                        <SelectItem value="Harvest">Harvest</SelectItem>
                        <SelectItem value="Dispatch">Dispatch</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Separator />

                  {/* Expected Stage Filter */}
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">
                      Expected Stage
                    </Label>
                    <Select
                      value={filters.expectedStage}
                      onValueChange={(v) =>
                        setFilters({ ...filters, expectedStage: v })
                      }
                    >
                      <SelectTrigger className="h-8 text-xs">
                        <SelectValue placeholder="Select expected stage" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Stages</SelectItem>
                        <SelectItem value="Sowing">Sowing</SelectItem>
                        <SelectItem value="Vegetative">Vegetative</SelectItem>
                        <SelectItem value="Detassling">Detassling</SelectItem>
                        <SelectItem value="Transplanting">
                          Transplanting
                        </SelectItem>
                        <SelectItem value="PPI">PPI</SelectItem>
                        <SelectItem value="Flowering">Flowering</SelectItem>
                        <SelectItem value="Harvest">Harvest</SelectItem>
                        <SelectItem value="Dispatch">Dispatch</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </ScrollArea>
              <div className="p-3 border-t bg-slate-50 flex justify-between items-center">
                <span className="text-xs text-slate-500">
                  {activeFilterCount} active filter
                  {activeFilterCount !== 1 ? "s" : ""}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs"
                  onClick={() => {
                    setFilters({
                      grower: "all",
                      assignedFieldAssistant: "all",
                      state: "all",
                      district: "all",
                      taluka: "all",
                      village: "all",
                      crop: "all",
                      hybrid: "all",
                      currentStage: "all",
                      expectedStage: "all",
                    });
                  }}
                >
                  Clear All
                </Button>
              </div>
            </PopoverContent>
          </Popover>

          {/* Search Bar */}
          <div className="relative flex-1">
            <Search className="absolute left-2 top-2 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search by Plot ID or Grower Name"
              className="pl-8 h-8 text-xs"
            />
          </div>
        </div>
      )}

      {/* View Mode Toggle - Floating Bottom Overlay - Hidden when forms are open */}
      {!isAddPlotOpen &&
        !isPreSeasonOpen &&
        !isSeasonDetailsOpen &&
        !isHarvestDetailsOpen &&
        !isTasksOpen &&
        !isAddTaskPageOpen &&
        !isCopyPlotOpen && (
          <div className="fixed bottom-[136px] left-1/2 -translate-x-1/2 z-50">
            <div className="inline-flex items-center bg-white border border-slate-200 rounded-lg p-1 gap-1 shadow-lg mx-[0px] my-[16px]">
              <Button
                variant="ghost"
                size="icon"
                className={`h-9 w-9 ${viewMode === "list" ? "bg-[#4CAF50] text-white" : "text-[#4CAF50] hover:bg-green-50"}`}
                onClick={() => setViewMode("list")}
              >
                <List className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className={`h-9 w-9 ${viewMode === "map" ? "bg-[#4CAF50] text-white" : "text-[#4CAF50] hover:bg-green-50"}`}
                onClick={() => setViewMode("map")}
              >
                <MapIcon className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}

      {/* Quick Audit Filters */}
      {viewMode === "list" && (
        <div className="flex items-center gap-2 overflow-x-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          <Button
            variant={auditFilter === "all" ? "default" : "outline"}
            size="sm"
            className={`h-8 text-xs whitespace-nowrap ${
              auditFilter === "all" ? "bg-[#4CAF50] hover:bg-[#388E3C]" : ""
            }`}
            onClick={() => setAuditFilter("all")}
          >
            All
          </Button>
          <Button
            variant={auditFilter === "audited" ? "default" : "outline"}
            size="sm"
            className={`h-8 text-xs whitespace-nowrap ${
              auditFilter === "audited" ? "bg-[#4CAF50] hover:bg-[#388E3C]" : ""
            }`}
            onClick={() => setAuditFilter("audited")}
          >
            Audited
          </Button>
          <Button
            variant={auditFilter === "pending" ? "default" : "outline"}
            size="sm"
            className={`h-8 text-xs whitespace-nowrap ${
              auditFilter === "pending" ? "bg-[#4CAF50] hover:bg-[#388E3C]" : ""
            }`}
            onClick={() => setAuditFilter("pending")}
          >
            Audit Pending
          </Button>
        </div>
      )}

      {/* Main Content Area */}
      {viewMode === "map" ? (
        <MockMapView />
      ) : (
        <div className="flex-1 h-0 overflow-y-auto space-y-3 pb-20">
          {filteredPlots.map((plot) => (
            <Card
              key={plot.id}
              onClick={() => setSelectedPlot(plot)}
              className="cursor-pointer transition-all hover:shadow-md active:scale-[0.98]"
            >
              <CardContent className="p-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3 className="font-semibold text-base truncate font-mono">
                      {plot.id}
                    </h3>
                    {plot.auditStatus === "audited" ? (
                      <Badge className="bg-green-100 hover:bg-green-100 text-green-700 border-green-200 flex items-center gap-1 shrink-0">
                        <CheckCircle2 className="h-3 w-3" />
                        Audited
                      </Badge>
                    ) : (
                      <Badge
                        variant="outline"
                        className="bg-slate-50 text-slate-600 border-slate-200 shrink-0"
                      >
                        Audit Pending
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-slate-500 mb-2">
                    {plot.growerName}
                  </p>
                  <div className="flex items-center gap-4 text-xs text-slate-400">
                    <div className="flex items-center gap-1">
                      <Sprout className="h-3.5 w-3.5" />
                      <span>{plot.crop}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-slate-400">({plot.hybrid})</span>
                    </div>
                  </div>
                  <div className="text-xs text-slate-400 mt-1">
                    Sowing Date:{" "}
                    {new Date(plot.sowingDate).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
