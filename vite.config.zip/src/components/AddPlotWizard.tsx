import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription, DialogFooter } from './ui/dialog';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { 
  Map as MapIcon, 
  Layers, 
  History, 
  PenTool, 
  MousePointer2, 
  AlertTriangle, 
  CheckCircle2, 
  Save, 
  Download, 
  Upload,
  Maximize2,
  Minimize2,
  AlertOctagon,
  Plus,
  Minus,
  MapPin,
  Footprints,
  Hexagon
} from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from "./ui/alert";

interface AddPlotWizardProps {
  isOpen: boolean;
  onClose: () => void;
  onSave?: (data: any) => void;
  initialData?: any;
  selectedRegion?: string;
  initialStep?: 1 | 2 | 3; // Add initialStep prop
}

export function AddPlotWizard({ isOpen, onClose, onSave, initialData, selectedRegion = 'all', initialStep = 1 }: AddPlotWizardProps) {
  const [step, setStep] = useState<1 | 2 | 3>(initialStep); // Use initialStep instead of hardcoded 1
  const [isolationError, setIsolationError] = useState(false);
  const [isStep1Expanded, setIsStep1Expanded] = useState(true);
  const [isSummaryExpanded, setIsSummaryExpanded] = useState(false);
  
  // Helper function to convert region value to display name
  const getStateDisplayName = (regionValue: string): string => {
    const stateMap: Record<string, string> = {
      'punjab': 'Punjab',
      'haryana': 'Haryana',
      'uttar-pradesh': 'Uttar Pradesh',
      'maharashtra': 'Maharashtra',
      'gujarat': 'Gujarat',
      'rajasthan': 'Rajasthan',
    };
    return stateMap[regionValue] || '';
  };
  
  // Pre-fill state if a specific region is selected
  const initialState = selectedRegion !== 'all' ? getStateDisplayName(selectedRegion) : (initialData?.state || '');
  
  const [formData, setFormData] = useState({
    grower: initialData?.grower || '',
    fieldAssistant: initialData?.fieldAssistant || '',
    state: initialState,
    district: initialData?.district || '',
    taluka: initialData?.taluka || '',
    village: initialData?.village || '',
    hybrid: initialData?.hybrid || '',
    purpose: initialData?.purpose || '',
    irrigation: initialData?.irrigation || '',
    soilMoisture: initialData?.soilMoisture || '',
    isolationObserved: initialData?.isolationObserved || '',
    crop: initialData?.crop || '',
    sowingDate: initialData?.sowingDate || '',
    estimatedAcreage: initialData?.estimatedAcreage || ''
  });

  // Grower to State mapping
  const growerStateMap: Record<string, string> = {
    'ramesh-kumar': 'Maharashtra',
    'suresh-patel': 'Maharashtra',
    'anita-singh': 'Telangana',
    'vikram-reddy': 'Telangana',
    'priya-sharma': 'Andhra Pradesh',
    'rajesh-gupta': 'Maharashtra',
    'amit-verma': 'Telangana',
    'sneha-patil': 'Maharashtra',
    'rahul-mehta': 'Andhra Pradesh',
    'kavita-rao': 'Telangana',
    'arjun-singh': 'Maharashtra',
    'meera-iyer': 'Andhra Pradesh',
    'deepak-kumar': 'Telangana',
    'sunita-williams': 'Maharashtra',
    'vijay-kumar': 'Andhra Pradesh',
  };

  // Step 2 States
  const [mapYear, setMapYear] = useState('2024');
  const [showLayers, setShowLayers] = useState(true);
  const [drawingMode, setDrawingMode] = useState<'none' | 'auto' | 'manual'>('none');
  const [hasErrors, setHasErrors] = useState(true); // Mocking initial errors for Step 2.1
  const [plotType, setPlotType] = useState<'new' | 'existing'>('new');

  // Update step when initialStep changes and wizard is opened
  useEffect(() => {
    if (isOpen) {
      setStep(initialStep);
      setIsolationError(false); // Reset error state when wizard opens
    }
  }, [isOpen, initialStep]);

  if (!isOpen) return null;

  const handleNext = () => {
    if (step === 1) {
      if (formData.isolationObserved === 'no') {
        setIsolationError(true);
        return;
      }
      setStep(2);
    }
  };

  const handleIsolationChange = (value: string) => {
    setFormData({ ...formData, isolationObserved: value });
    if (value === 'yes') setIsolationError(false);
  };

  return (
    <div className="absolute inset-0 z-50 bg-white flex flex-col animate-in fade-in slide-in-from-bottom duration-300">
      <div className="px-4 py-3 border-b bg-[rgb(76,175,80)] text-white flex justify-between items-center">
          <div className="flex-1">
            <h2 className="text-lg font-bold leading-none">Add New Plot</h2>
            <p className="text-xs mt-1 text-white/80">Step {step} of 3</p>
          </div>
          <div className="flex flex-col items-end gap-2">
            <div className="flex items-center gap-1.5 bg-white px-2 py-1 rounded-full">
              <div className="h-1.5 w-1.5 rounded-full bg-[#4CAF50] animate-pulse" />
              <span className="text-[9px] text-[#4CAF50] font-medium">Connected</span>
            </div>
          </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 pb-6 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
        {step === 1 ? (
          <div className="space-y-4">
            {/* Step 1: Plot Details */}
            <div className="space-y-4">
                <div className="pb-2">
                  <h3 className="text-lg font-bold">Plot Details</h3>
                  <p className="text-sm text-slate-500">Fill in the required information</p>
                </div>
                {isStep1Expanded && (
                <div className="space-y-4">
                  <div className="space-y-2">
                      <Label className="text-base font-medium">Grower <span className="text-red-500">*</span></Label>
                      <Select onValueChange={(v) => {
                        const state = growerStateMap[v] || '';
                        setFormData({...formData, grower: v, state: state});
                      }}>
                        <SelectTrigger className="h-12 text-base"><SelectValue placeholder="Select Grower" /></SelectTrigger>
                        <SelectContent className="max-h-[300px]">
                            <SelectItem value="ramesh-kumar">Ramesh Kumar</SelectItem>
                            <SelectItem value="suresh-patel">Suresh Patel</SelectItem>
                            <SelectItem value="anita-singh">Anita Singh</SelectItem>
                            <SelectItem value="vikram-reddy">Vikram Reddy</SelectItem>
                            <SelectItem value="priya-sharma">Priya Sharma</SelectItem>
                            <SelectItem value="rajesh-gupta">Rajesh Gupta</SelectItem>
                            <SelectItem value="amit-verma">Amit Verma</SelectItem>
                            <SelectItem value="sneha-patil">Sneha Patil</SelectItem>
                            <SelectItem value="rahul-mehta">Rahul Mehta</SelectItem>
                            <SelectItem value="kavita-rao">Kavita Rao</SelectItem>
                            <SelectItem value="arjun-singh">Arjun Singh</SelectItem>
                            <SelectItem value="meera-iyer">Meera Iyer</SelectItem>
                            <SelectItem value="deepak-kumar">Deepak Kumar</SelectItem>
                            <SelectItem value="sunita-williams">Sunita Williams</SelectItem>
                            <SelectItem value="vijay-kumar">Vijay Kumar</SelectItem>
                            <SelectItem value="manual_entry" className="font-medium text-blue-600 focus:text-blue-700 border-t mt-1">
                              + Add Manually
                            </SelectItem>
                        </SelectContent>
                      </Select>
                  </div>
                  <div className="space-y-2">
                      <Label className="text-base font-medium">Assigned Field Assistant <span className="text-red-500">*</span></Label>
                      <Select onValueChange={(v) => setFormData({...formData, fieldAssistant: v})}>
                        <SelectTrigger className="h-12 text-base"><SelectValue placeholder="Select Field Assistant" /></SelectTrigger>
                        <SelectContent className="max-h-[300px]">
                            <SelectItem value="rajiv-sharma">Rajiv Sharma</SelectItem>
                            <SelectItem value="amit-patel">Amit Patel</SelectItem>
                            <SelectItem value="neha-desai">Neha Desai</SelectItem>
                            <SelectItem value="sandeep-reddy">Sandeep Reddy</SelectItem>
                            <SelectItem value="pooja-singh">Pooja Singh</SelectItem>
                            <SelectItem value="vikrant-joshi">Vikrant Joshi</SelectItem>
                            <SelectItem value="anjali-mehta">Anjali Mehta</SelectItem>
                            <SelectItem value="karan-verma">Karan Verma</SelectItem>
                            <SelectItem value="manual_entry" className="font-medium text-blue-600 focus:text-blue-700 border-t mt-1">
                              + Add Manually
                            </SelectItem>
                        </SelectContent>
                      </Select>
                  </div>
                  
                  <div className="border-t border-slate-200 my-2"></div>
                  
                  <div className="space-y-2">
                      <Label className="text-base font-medium">State <span className="text-red-500">*</span></Label>
                      <div className="px-4 py-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 text-base">
                        {formData.state || 'Auto-populated from Grower'}
                      </div>
                  </div>
                  <div className="space-y-2">
                      <Label className="text-base font-medium">District <span className="text-red-500">*</span></Label>
                      <Select onValueChange={(v) => setFormData({...formData, district: v})}>
                        <SelectTrigger className="h-12 text-base"><SelectValue placeholder="Select District" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="district-a">District A</SelectItem>
                            <SelectItem value="district-b">District B</SelectItem>
                            <SelectItem value="manual_entry" className="font-medium text-blue-600 focus:text-blue-700 border-t mt-1">
                              + Add Manually
                            </SelectItem>
                        </SelectContent>
                      </Select>
                  </div>
                  <div className="space-y-2">
                      <Label className="text-base font-medium">Taluka <span className="text-red-500">*</span></Label>
                      <Select onValueChange={(v) => setFormData({...formData, taluka: v})}>
                        <SelectTrigger className="h-12 text-base"><SelectValue placeholder="Select Taluka" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="taluka-x">Taluka X</SelectItem>
                            <SelectItem value="taluka-y">Taluka Y</SelectItem>
                            <SelectItem value="manual_entry" className="font-medium text-blue-600 focus:text-blue-700 border-t mt-1">
                              + Add Manually
                            </SelectItem>
                        </SelectContent>
                      </Select>
                  </div>
                  <div className="space-y-2">
                      <Label className="text-base font-medium">Village <span className="text-red-500">*</span></Label>
                      <Select onValueChange={(v) => setFormData({...formData, village: v})}>
                        <SelectTrigger className="h-12 text-base"><SelectValue placeholder="Select Village" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="village-alpha">Village Alpha</SelectItem>
                            <SelectItem value="village-beta">Village Beta</SelectItem>
                            <SelectItem value="manual_entry" className="font-medium text-blue-600 focus:text-blue-700 border-t mt-1">
                              + Add Manually
                            </SelectItem>
                        </SelectContent>
                      </Select>
                  </div>
                  
                  <div className="border-t border-slate-200 my-2"></div>
                  
                  <div className="space-y-2">
                      <Label className="text-base font-medium">Plot Purpose <span className="text-red-500">*</span></Label>
                      <Select onValueChange={(v) => setFormData({...formData, purpose: v})}>
                        <SelectTrigger className="h-12 text-base"><SelectValue placeholder="Select Purpose" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="all_hybrids">All Hybrids</SelectItem>
                            <SelectItem value="rice_hybrids">Rice Hybrids</SelectItem>
                            <SelectItem value="manual_entry" className="font-medium text-blue-600 focus:text-blue-700 border-t mt-1">
                              + Add Manually
                            </SelectItem>
                        </SelectContent>
                      </Select>
                  </div>
                  <div className="space-y-2">
                      <Label className="text-base font-medium">Irrigation Method <span className="text-red-500">*</span></Label>
                      <Select onValueChange={(v) => setFormData({...formData, irrigation: v})}>
                        <SelectTrigger className="h-12 text-base"><SelectValue placeholder="Select Method" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="drip">Drip</SelectItem>
                            <SelectItem value="flood">Flood</SelectItem>
                            <SelectItem value="rainfed">Rainfed</SelectItem>
                            <SelectItem value="manual_entry" className="font-medium text-blue-600 focus:text-blue-700 border-t mt-1">
                              + Add Manually
                            </SelectItem>
                        </SelectContent>
                      </Select>
                  </div>
                  <div className="space-y-2">
                      <Label className="text-base font-medium">Isolation Observed <span className="text-red-500">*</span></Label>
                      <div className="flex items-center gap-3 h-12 px-4 border rounded-lg bg-white">
                        <button
                          type="button"
                          onClick={() => handleIsolationChange('yes')}
                          className={`flex-1 h-8 rounded-md transition-all ${
                            formData.isolationObserved === 'yes'
                              ? 'bg-[#4CAF50] text-white'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          Yes
                        </button>
                        <button
                          type="button"
                          onClick={() => handleIsolationChange('no')}
                          className={`flex-1 h-8 rounded-md transition-all ${
                            formData.isolationObserved === 'no'
                              ? 'bg-red-500 text-white'
                              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          No
                        </button>
                      </div>
                  </div>
                  
                  <div className="border-t border-slate-200 my-2"></div>
                  
                  <div className="space-y-2">
                      <Label className="text-base font-medium">Crop <span className="text-red-500">*</span></Label>
                      <Select onValueChange={(v) => setFormData({...formData, crop: v})}>
                        <SelectTrigger className="h-12 text-base"><SelectValue placeholder="Select Crop" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="corn">Corn</SelectItem>
                            <SelectItem value="rice">Rice</SelectItem>
                            <SelectItem value="wheat">Wheat</SelectItem>
                            <SelectItem value="cotton">Cotton</SelectItem>
                            <SelectItem value="soybean">Soybean</SelectItem>
                            <SelectItem value="manual_entry" className="font-medium text-blue-600 focus:text-blue-700 border-t mt-1">
                              + Add Manually
                            </SelectItem>
                        </SelectContent>
                      </Select>
                  </div>
                  <div className="space-y-2">
                      <Label className="text-base font-medium">Hybrid Type <span className="text-red-500">*</span></Label>
                      <Select onValueChange={(v) => setFormData({...formData, hybrid: v})}>
                        <SelectTrigger className="h-12 text-base"><SelectValue placeholder="Select Hybrid Type" /></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="super-99">Super-99 (North)</SelectItem>
                            <SelectItem value="rice-gold">Rice-Gold (North)</SelectItem>
                            <SelectItem value="cotton-x">Cotton-X (South)</SelectItem>
                            <SelectItem value="manual_entry" className="font-medium text-blue-600 focus:text-blue-700 border-t mt-1">
                              + Add Manually
                            </SelectItem>
                        </SelectContent>
                      </Select>
                  </div>
                  <div className="space-y-2">
                      <Label className="text-base font-medium">Estimated Acreage <span className="text-red-500">*</span></Label>
                      <Input 
                        type="number" 
                        step="0.01"
                        placeholder="Enter acreage" 
                        className="h-12 text-base"
                        value={formData.estimatedAcreage}
                        onChange={(e) => setFormData({...formData, estimatedAcreage: e.target.value})}
                      />
                  </div>
                </div>
                )}
                {isolationError && (
                    <Alert variant="destructive">
                      <AlertOctagon className="h-4 w-4" />
                      <AlertTitle>Isolation Conflict Detected</AlertTitle>
                      <AlertDescription>
                          This plot cannot be registered for seed production without proper isolation. Please review the field setup.
                      </AlertDescription>
                    </Alert>
                )}
            </div>
          </div>
        ) : step === 2 ? (
          <div className="h-full flex flex-col">
              <div className="pb-2 mb-4">
                <h3 className="text-lg font-bold">Plot Mapping</h3>
                <p className="text-sm text-slate-500">Choose your mapping method</p>
              </div>
              {/* Zoomed Out Field View with Plot Outline */}
              <div className="flex-1 relative overflow-hidden">
                {/* Background Image */}
                <div 
                  className="absolute inset-0 bg-cover bg-center"
                  style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1722082840106-c6508ee966ea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYXRlbGxpdGUlMjBhZ3JpY3VsdHVyYWwlMjBwbG90c3xlbnwxfHx8fDE3NjUzNjc2NDB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral)' }}
                ></div>

                {/* Overlay Buttons */}
                <div className="absolute bottom-6 right-6 flex flex-col gap-3">
                  <Button 
                    size="icon"
                    className="h-14 w-14 rounded-full bg-white hover:bg-white shadow-xl border-2 border-slate-300"
                    onClick={() => setDrawingMode('manual')}
                  >
                    <svg className="h-6 w-6 text-[#4CAF50]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M11 3 L17 4 L21 7 L23 12 L20 17 L18 21 L13 22 L8 20 L4 16 L2 10 L5 6 L8 4 Z" />
                    </svg>
                  </Button>

                  <Button 
                    size="icon"
                    className="h-14 w-14 rounded-full bg-white hover:bg-white shadow-xl border-2 border-slate-300"
                    onClick={() => setDrawingMode('auto')}
                  >
                    <MapPin className="h-6 w-6 text-[#4CAF50]" />
                  </Button>
                </div>
              </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Step 3: Summary */}
            <div className="pb-2">
              <h3 className="text-lg font-bold">Plot Summary</h3>
              <p className="text-sm text-slate-500">Review your plot details before submitting</p>
            </div>

            {/* Plot Details Summary */}
            <div className="bg-white border rounded-lg p-4 space-y-3">
              <h4 className="font-bold text-base text-[rgb(26,26,26)]">Plot Details</h4>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-slate-500">Grower</p>
                  <p className="font-medium">{formData.grower || 'Not selected'}</p>
                </div>
                <div>
                  <p className="text-slate-500">Field Assistant</p>
                  <p className="font-medium">{formData.fieldAssistant || 'Not selected'}</p>
                </div>
                <div>
                  <p className="text-slate-500">State</p>
                  <p className="font-medium">{formData.state || 'Not set'}</p>
                </div>
                <div>
                  <p className="text-slate-500">District</p>
                  <p className="font-medium">{formData.district || 'Not selected'}</p>
                </div>
                <div>
                  <p className="text-slate-500">Taluka</p>
                  <p className="font-medium">{formData.taluka || 'Not selected'}</p>
                </div>
                <div>
                  <p className="text-slate-500">Village</p>
                  <p className="font-medium">{formData.village || 'Not selected'}</p>
                </div>
                <div>
                  <p className="text-slate-500">Plot Purpose</p>
                  <p className="font-medium">{formData.purpose || 'Not selected'}</p>
                </div>
                <div>
                  <p className="text-slate-500">Irrigation</p>
                  <p className="font-medium">{formData.irrigation || 'Not selected'}</p>
                </div>
                <div>
                  <p className="text-slate-500">Isolation Observed</p>
                  <p className="font-medium">{formData.isolationObserved || 'Not selected'}</p>
                </div>
                <div>
                  <p className="text-slate-500">Crop</p>
                  <p className="font-medium">{formData.crop || 'Not selected'}</p>
                </div>
                <div>
                  <p className="text-slate-500">Hybrid Type</p>
                  <p className="font-medium">{formData.hybrid || 'Not selected'}</p>
                </div>
                <div>
                  <p className="text-slate-500">Estimated Acreage</p>
                  <p className="font-medium">{formData.estimatedAcreage || 'Not set'}</p>
                </div>
              </div>
            </div>

            {/* Plot Map Summary */}
            <div className="bg-white border rounded-lg p-4 space-y-3">
              <h4 className="font-bold text-base text-[rgb(26,26,26)]">Plot Map</h4>
              
              {/* Map Preview */}
              <div className="relative h-48 bg-slate-100 rounded-lg overflow-hidden">
                <div 
                  className="absolute inset-0 bg-cover bg-center"
                  style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1726433890104-dcee8e781896?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZXJpYWwlMjBmYXJtJTIwZmllbGQlMjBib3VuZGFyeXxlbnwxfHx8fDE3NjQ5MzYyMjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral)' }}
                ></div>
                <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 100 100" preserveAspectRatio="none">
                  <polygon 
                    points="25,35 70,30 75,65 30,70" 
                    fill="rgba(76, 175, 80, 0.15)" 
                    stroke="rgba(76, 175, 80, 0.8)" 
                    strokeWidth="0.8"
                    strokeDasharray="2,1"
                  />
                </svg>
              </div>

              {/* Audited Acreage */}
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-lg border border-green-200">
                <p className="text-sm text-slate-600 mb-1">Audited Acreage</p>
                <p className="text-3xl font-bold text-[#4CAF50]">2.45</p>
                <p className="text-xs text-slate-500 mt-1">acres</p>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t bg-white shadow-2xl">
        <div className="flex gap-2">
            {step === 1 ? (
                <>
                  <Button variant="ghost" className="h-10 text-sm px-3" onClick={onClose}>
                    Cancel
                  </Button>
                  <Button variant="outline" className="h-10 text-sm px-3" onClick={onClose}>
                    <Save className="h-4 w-4" />
                  </Button>
                  <Button className="flex-1 h-10 bg-[#4CAF50] hover:bg-[#388E3C] text-sm" onClick={handleNext}>
                    Proceed
                  </Button>
                </>
            ) : step === 2 ? (
                <>
                  <Button variant="ghost" className="h-10 text-sm px-3" onClick={() => setStep(1)}>
                    Back
                  </Button>
                  <Button variant="outline" className="h-10 text-sm px-3" onClick={onClose}>
                    <Save className="h-4 w-4" />
                  </Button>
                  <Button 
                    className="flex-1 h-10 text-sm bg-[#4CAF50] hover:bg-[#388E3C]" 
                    onClick={() => setStep(3)}
                  >
                    Proceed
                  </Button>
                </>
            ) : (
                <>
                  <Button variant="ghost" className="h-10 text-sm px-3" onClick={() => setStep(2)}>
                    Back
                  </Button>
                  <Button variant="outline" className="h-10 text-sm px-3" onClick={onClose}>
                    <Save className="h-4 w-4" />
                  </Button>
                  <Button 
                    className="flex-1 h-10 text-sm bg-[#4CAF50] hover:bg-[#388E3C]" 
                    onClick={() => {
                      onSave?.(formData);
                      onClose();
                    }}
                  >
                    Submit
                  </Button>
                </>
            )}
        </div>
      </div>
    </div>
  );
}