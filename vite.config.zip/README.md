
  # [Wireframes] Field Assistant Dashboard Mobile

  This is a code bundle for [Wireframes] Field Assistant Dashboard Mobile. The original project is available at https://www.figma.com/design/3aMgQVywsnwiTStFPLdCKb/-Wireframes--Field-Assistant-Dashboard-Mobile.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  